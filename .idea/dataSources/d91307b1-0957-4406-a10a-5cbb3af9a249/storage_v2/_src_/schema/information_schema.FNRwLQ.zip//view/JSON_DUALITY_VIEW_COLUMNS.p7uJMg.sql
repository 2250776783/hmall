create view JSON_DUALITY_VIEW_COLUMNS as
select `cat`.`name`                                               AS `TABLE_CATALOG`,
       `sch`.`name`                                               AS `TABLE_SCHEMA`,
       `tbl`.`name`                                               AS `TABLE_NAME`,
       (`columns`.`referenced_table_catalog` collate utf8mb4_bin) AS `REFERENCED_TABLE_CATALOG`,
       (`columns`.`referenced_table_schema` collate utf8mb4_bin)  AS `REFERENCED_TABLE_SCHEMA`,
       (`columns`.`referenced_table_name` collate utf8mb4_bin)    AS `REFERENCED_TABLE_NAME`,
       `columns`.`is_root_table`                                  AS `IS_ROOT_TABLE`,
       `columns`.`referenced_table_id`                            AS `REFERENCED_TABLE_ID`,
       `columns`.`referenced_column_name`                         AS `REFERENCED_COLUMN_NAME`,
       `columns`.`json_key_name`                                  AS `JSON_KEY_NAME`,
       `columns`.`allow_insert`                                   AS `ALLOW_INSERT`,
       `columns`.`allow_update`                                   AS `ALLOW_UPDATE`,
       `columns`.`allow_delete`                                   AS `ALLOW_DELETE`,
       `columns`.`read_only`                                      AS `READ_ONLY`
from (((`mysql`.`tables` `tbl` join `mysql`.`schemata` `sch`
        on ((`tbl`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat`
       on ((`cat`.`id` = `sch`.`catalog_id`))) join json_table(
        get_jdv_property_key_value(`sch`.`name`, `tbl`.`name`, get_dd_property_key_value(`tbl`.`options`, 'view_valid'),
                                   'JSON_DUALITY_VIEW_COLUMNS'), '$.entries[*]'
        columns (`referenced_table_id` int path '$.referenced_table_id', `referenced_table_catalog` varchar(64) character set utf8mb4 path '$.referenced_table_catalog', `referenced_table_schema` varchar(64) character set utf8mb4 path '$.referenced_table_schema', `referenced_table_name` varchar(64) character set utf8mb4 path '$.referenced_table_name', `is_root_table` tinyint path '$.is_root_table', `referenced_column_name` varchar(64) character set utf8mb4 path '$.referenced_column_name', `json_key_name` varchar(64) character set utf8mb4 path '$.json_key_name', `allow_insert` tinyint path '$.allow_insert', `allow_update` tinyint path '$.allow_update', `allow_delete` tinyint path '$.allow_delete', `read_only` tinyint path '$.read_only')) `columns`)
where ((0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`)) and (0 <>
                                                                                                      can_access_column(
                                                                                                              `columns`.`referenced_table_schema`,
                                                                                                              `columns`.`referenced_table_name`,
                                                                                                              `columns`.`referenced_column_name`)) and
       (`tbl`.`type` = 'VIEW') and (get_dd_property_key_value(`tbl`.`options`, 'view_type') = 'JSON_DUALITY'));

