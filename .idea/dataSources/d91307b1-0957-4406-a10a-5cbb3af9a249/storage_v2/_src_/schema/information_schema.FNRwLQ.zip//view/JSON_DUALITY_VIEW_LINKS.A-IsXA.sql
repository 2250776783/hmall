create view JSON_DUALITY_VIEW_LINKS as
select `cat`.`name`                                              AS `TABLE_CATALOG`,
       `sch`.`name`                                              AS `TABLE_SCHEMA`,
       `tbl`.`name`                                              AS `TABLE_NAME`,
       (`links`.`parent_table_catalog` collate utf8mb4_bin)      AS `PARENT_TABLE_CATALOG`,
       (`links`.`parent_table_schema` collate utf8mb4_bin)       AS `PARENT_TABLE_SCHEMA`,
       (`links`.`parent_table_name` collate utf8mb4_bin)         AS `PARENT_TABLE_NAME`,
       (`links`.`child_table_catalog` collate utf8mb4_bin)       AS `CHILD_TABLE_CATALOG`,
       (`links`.`child_table_schema` collate utf8mb4_bin)        AS `CHILD_TABLE_SCHEMA`,
       (`links`.`child_table_name` collate utf8mb4_bin)          AS `CHILD_TABLE_NAME`,
       (`links`.`parent_column_name` collate utf8mb4_0900_ai_ci) AS `PARENT_COLUMN_NAME`,
       (`links`.`child_column_name` collate utf8mb4_0900_ai_ci)  AS `CHILD_COLUMN_NAME`,
       `links`.`join_type`                                       AS `JOIN_TYPE`,
       `links`.`json_key_name`                                   AS `JSON_KEY_NAME`
from (((`mysql`.`tables` `tbl` join `mysql`.`schemata` `sch`
        on ((`tbl`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat`
       on ((`cat`.`id` = `sch`.`catalog_id`))) join json_table(
        get_jdv_property_key_value(`sch`.`name`, `tbl`.`name`, get_dd_property_key_value(`tbl`.`options`, 'view_valid'),
                                   'JSON_DUALITY_VIEW_LINKS'), '$.entries[*]'
        columns (`parent_table_catalog` varchar(64) character set utf8mb4 path '$.parent_table_catalog', `parent_table_schema` varchar(64) character set utf8mb4 path '$.parent_table_schema', `parent_table_name` varchar(64) character set utf8mb4 path '$.parent_table_name', `parent_column_name` varchar(64) character set utf8mb4 path '$.parent_column_name', `child_table_catalog` varchar(64) character set utf8mb4 path '$.child_table_catalog', `child_table_schema` varchar(64) character set utf8mb4 path '$.child_table_schema', `child_table_name` varchar(64) character set utf8mb4 path '$.child_table_name', `child_column_name` varchar(64) character set utf8mb4 path '$.child_column_name', `join_type` varchar(64) character set utf8mb4 path '$.join_type', `json_key_name` varchar(64) character set utf8mb4 path '$.json_key_name')) `links`)
where ((0 <> can_access_view(`sch`.`name`, `tbl`.`name`, `tbl`.`view_definer`, `tbl`.`options`)) and (0 <>
                                                                                                      can_access_column(
                                                                                                              `links`.`parent_table_schema`,
                                                                                                              `links`.`parent_table_name`,
                                                                                                              `links`.`parent_column_name`)) and
       (0 <>
        can_access_column(`links`.`child_table_schema`, `links`.`child_table_name`, `links`.`child_column_name`)) and
       (`tbl`.`type` = 'VIEW') and (get_dd_property_key_value(`tbl`.`options`, 'view_type') = 'JSON_DUALITY'));

